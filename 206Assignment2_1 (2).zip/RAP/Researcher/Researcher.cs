﻿/* Research Assessment Program (RAP)
 * 
 * Researcher.cs
 * Abstract class for Staff or Student
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.ComponentModel;
using System.Collections.Generic;

namespace RAP.Research
{
    public enum Campus { Hobart, Launceston };
    public abstract class Researcher
    {
        // Attributes set with initial db fetch
        public int Id { get; set; }
        public string Title { get; set; }
        public string GivenName { get; set; }
        public string FamilyName { get; set; }
        public EmploymentLevel CurrentJob { get; set; }

        // Attributes set with subsequent db fetch
        public Campus Campus { get; set; }
        public string School { get; set; }
        public string Email { get; set; }
        public string Image { get; set; }
        public DateTime CurrentJobStart { get; set; }
        public DateTime StartDate { get; set; }
        public List<Publication> Publications { get; set; }

        // Attributes calculated from others
        public string CurrentJobTitle { get { return EnumString.Description(CurrentJob); } }
        public double Tenure { get { return DateTime.Today.Subtract(StartDate).TotalDays / 365.2425; } }
    }
}