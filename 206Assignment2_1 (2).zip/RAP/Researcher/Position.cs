﻿/* Research Assessment Program (RAP)
 * 
 * Position.cs
 * Current or previous positions of Researcher objects
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.ComponentModel;

namespace RAP.Research
{
    public enum EmploymentLevel
    {
        [Description("All Categories")] Unspecified, Student,
        [Description("Post-Doctoral")] A,
        [Description("Lecturer")] B,
        [Description("Senior Lecturer")] C,
        [Description("Associate Professor")] D,
        [Description("Professor")] E
    }

    public class Position
    {
        // Fields for values from database
        public EmploymentLevel Level { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public string Title { get { return EnumString.Description(Level); } }
    }
}