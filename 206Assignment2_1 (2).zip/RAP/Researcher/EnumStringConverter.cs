﻿/* Research Assessment Program (RAP)
 * 
 * EnumStringConverted.cs
 * Converting enum values to WPF-Friendly strings
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.Windows.Data;
using System.Globalization;
using RAP.Research;
using RAP.Control;

namespace RAP.View
{
    // Overriding conversion with data binding to enums
    public class EnumStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // The enum value's description will be displayed by ToString()
            if (value is Campus)
            {
                return ((Campus)value).Description();
            }
            else if (parameter.ToString() == "EmploymentLevels")
            {
                var valuestring = value.ToString();
                return valuestring.ToEnum<EmploymentLevel>().Description();
            }
            else if (parameter.ToString() == "Performances")
            {
                var valuestring = value.ToString();
                return valuestring.ToEnum<PerformanceTier>().Description();
            }
            else
            {
                return value.ToString();
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
        }
    }
}