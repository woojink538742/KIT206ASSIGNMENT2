﻿/* Research Assessment Program (RAP)
 * 
 * Publication.cs
 * Publications of Researcher objects
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;

namespace RAP.Research
{
    public enum OutputType { Conference, Journal, Other };
    public class Publication
    {
        // Fields for values from database
        public string Doi { get; set; }
        public string Title { get; set; }
        public string Authors { get; set; }
        public int PublicationYear { get; set; }
        public OutputType Type { get; set; }
        public string CiteAs { get; set; }
        public DateTime Available { get; set; }
        public int Age { get { return DateTime.Today.Year - PublicationYear; } }
    }
}