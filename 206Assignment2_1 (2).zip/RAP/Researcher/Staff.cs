﻿/* Research Assessment Program (RAP)
 * 
 * Staff.cs
 * Specialisation of Researcher class
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.Collections.Generic;

namespace RAP.Research
{
    // Attributes unique to Staff Researcher type
    public class Staff : Researcher
    {
        public List<Position> Positions { get; set; }
        public List<string> Supervisees { get; set; }
        private double ExpectedPublications
        {
            get
            {
                switch (CurrentJob)
                {
                    case EmploymentLevel.A: return 0.5;
                    case EmploymentLevel.B: return 1;
                    case EmploymentLevel.C: return 2;
                    case EmploymentLevel.D: return 3.2;
                    case EmploymentLevel.E: return 4;
                    default: return 0;
                }
            }
        }

        // Researcher Details View should show calculated performance
        public double ThreeYearAverage
        {
            get
            {
                int count = 0;
                int thisYear = DateTime.Today.Year;

                // Get count of publications from the last three full years
                for (int i = 0; i < Publications.Count; i++)
                {
                    if (thisYear - 3 <= Publications[i].PublicationYear
                        && Publications[i].PublicationYear < thisYear)
                    {
                        count++;
                    }
                }
                return count / 3.0;
            }
        }

        public double Performance { get { return ThreeYearAverage / ExpectedPublications; } }

        public int RecentPublicationCount { get; set; }
        public double PerformanceMetric { get { return (RecentPublicationCount / 3.0) / ExpectedPublications; } }
    }
}