﻿/* Research Assessment Program (RAP)
 * 
 * Student.cs
 * Specialisation of Researcher class
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

namespace RAP.Research
{
    public class Student : Researcher
    {
        // Attributes unique to Student Researcher Type
        public string Degree { get; set; }
        public string Supervisor { get; set; }
    }
}