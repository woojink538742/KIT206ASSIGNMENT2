﻿// TBD

using System;
using System.Collections.Generic;
using RAP.Research;
using RAP.Control; //===========================================

namespace RAP
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            ResearcherController rc = new ResearcherController();
            PublicationsController pc = new PublicationsController();

            Console.WriteLine("Fetching researchers from Database:\n");
            foreach (Researcher r in rc.researchers)
            {
                rc.LoadResearcherDetails(r);
                Console.WriteLine(r.ToString() + "\n");
            }
            Console.WriteLine("Entries found: {0}\n", rc.researchers.Count);


            List<Researcher> refinedListA = rc.FilterBy(EmploymentLevel.A);
            Console.WriteLine("Filtering by Category A:\n");
            foreach (Researcher r in refinedListA)
            {
                Console.WriteLine(r.ToString());
            }
            Console.WriteLine("Results: {0}\n", refinedListA.Count);


            List<Researcher> refinedListS = rc.FilterBy(EmploymentLevel.S);
            Console.WriteLine("Filtering by Category S:\n");
            foreach (Researcher r in refinedListS)
            {
                Console.WriteLine(r.ToString());
            }
            Console.WriteLine("Results: {0}\n", refinedListS.Count);

            List<Researcher> searchedListAN = rc.FilterBy("an");
            Console.WriteLine("Searching by \"an\":\n");
            foreach (Researcher r in searchedListAN)
            {
                Console.WriteLine(r.ToString());
            }
            Console.WriteLine("Results: {0}\n", searchedListAN.Count);


            List<Researcher> searchedListLI = rc.FilterBy("li");
            Console.WriteLine("Searching by \"li\":\n");
            foreach (Researcher r in searchedListLI)
            {
                Console.WriteLine(r.ToString());
            }
            Console.WriteLine("Results: {0}\n", searchedListLI.Count);


            rc.LoadResearcherDetails(rc.researchers[1]);
            Console.WriteLine("Loading details of Researcher #{0}:\n", rc.researchers[1].id);
            Console.WriteLine(rc.researchers[1].ToString() + "\n");


            rc.LoadResearcherDetails(rc.researchers[2]);
            Console.WriteLine("Loading details of Researcher #{0}:\n", rc.researchers[2].id);
            Console.WriteLine(rc.researchers[2].ToString() + "\n");


            List<Publication> publications = pc.LoadPublicationsFor(rc.researchers[2]);
            Console.WriteLine("Loading publications of Researcher #{0}:\n", rc.researchers[2].id);
            foreach (Publication p in publications)
            {
                Console.WriteLine(p.ToString() + "\n");
            }
            Console.WriteLine("Results: {0}\n", publications.Count);


            List<Position> positions = rc.GetPositions(rc.researchers[4]);
            Console.WriteLine("Loading position history of Researcher #{0}:\n", rc.researchers[4].id);
            foreach (Position p in positions)
            {
                Console.WriteLine(p.ToString());
            }
            Console.WriteLine("Results: {0}\n", positions.Count);
        }
    }
}
