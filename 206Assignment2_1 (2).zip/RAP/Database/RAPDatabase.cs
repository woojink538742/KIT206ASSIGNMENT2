﻿/* Research Assessment Program (RAP)
 * 
 * RAPDatabase.cs
 * Abstract class for database query
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using RAP.Research;

namespace RAP.Database
{
    public static class RAPDatabase
    {

        // Build static connection to the remote database 
        private static MySqlConnection connection = null;

        // The login credentials for connection to the remote database
        private const string data = "kit206";
        private const string user = "kit206";
        private const string pswd = "kit206";
        private const string serv = "alacritas.cis.utas.edu.au";

        // Creates connection to the database and returns (but does not open).
        private static MySqlConnection GetConnection()
        {
            if (connection == null)
            {
                string connectionDetails = String.Format("Database={0};Data Source={1};User Id={2};Password={3}", data, serv, user, pswd);
                connection = new MySqlConnection(connectionDetails);
            }
            return connection;
        }

        // Fetch details of all entries in researcher table
        public static List<Researcher> FetchResearcherDetails()
        {
            List<Researcher> researchers = new List<Researcher>();
            MySqlConnection connection = GetConnection();
            MySqlDataReader reader = null;

            // Start fetching process
            try
            {
                connection.Open();

                MySqlCommand command = new MySqlCommand("select type, id, title, given_name, family_name, level, email from researcher", connection);
                reader = command.ExecuteReader();

                // Get Staff researcher details
                while (reader.Read())
                {
                    if (reader.GetString(0) == "Staff")
                    {
                        researchers.Add(new Staff
                        {
                            Id = reader.GetInt32(1),
                            Title = reader.GetString(2),
                            GivenName = reader.GetString(3),
                            FamilyName = reader.GetString(4),
                            CurrentJob = reader.GetString(5).ToEnum<EmploymentLevel>(),
                            Email = reader.GetString(6)
                        });
                    }
                }

                // Get Student researcher details
                while (reader.Read())
                {
                    if (reader.GetString(0) == "Student")
                    {
                        researchers.Add(new Student
                        {
                            Id = reader.GetInt32(1),
                            Title = reader.GetString(2),
                            GivenName = reader.GetString(3),
                            FamilyName = reader.GetString(4),
                            CurrentJob = reader.GetString(0).ToEnum<EmploymentLevel>(),
                            Email = reader.GetString(6)
                        });
                    }
                }
            }

            // Catch fetching errors
            catch (MySqlException error)
            {
                Console.WriteLine("Error connecting to Database: " + error);
            }

            // Close any remaining connections
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (connection != null)
                {
                    connection.Close();
                }
            }
            researchers.Sort((researcher1, researcher2) => researcher1.FamilyName.CompareTo(researcher2.FamilyName));
            return researchers;
        }

        // Fetch publication count details for calculate performance metric
        public static List<int> FetchPublicationsBasic()
        {
            List<int> publicationIDs = new List<int>();
            int thisYear = DateTime.Today.Year;
            MySqlConnection connection = GetConnection();
            MySqlDataReader reader = null;

            // Start fetching process
            try
            {
                connection.Open();

                MySqlCommand command1 = new MySqlCommand("select rp.researcher_id, p.year from researcher_publication as rp, publication as p where rp.doi = p.doi", connection);
                reader = command1.ExecuteReader();

                while (reader.Read())
                {
                    if (reader.GetInt32(1) < thisYear && reader.GetInt32(1) >= thisYear - 3)
                    {
                        publicationIDs.Add(reader.GetInt32(0));
                    }
                }
            }

            // Catch Fetching errors
            catch (MySqlException error)
            {
                Console.WriteLine("Error connecting to Database: " + error);
            }

            finally
            {
                if (reader != null) { reader.Close(); }
                if (connection != null) { connection.Close(); }
            }
            return publicationIDs;
        }

        // Fetch full details of an entry in researcher table
        public static void FetchResearcherFull(Researcher r)
        {
            List<Publication> publications = new List<Publication>();
            MySqlConnection connection = GetConnection();
            MySqlDataReader reader = null;

            // Start fetching process
            try
            {
                connection.Open();

                MySqlCommand command1 = new MySqlCommand("select campus, unit, photo, current_start, utas_start, degree, supervisor_id from researcher where id = '" + r.Id + "'", connection);
                reader = command1.ExecuteReader();

                if (reader.Read())
                {
                    r.Campus = reader.GetString(0).EnumValue<Campus>();
                    r.School = reader.GetString(1);
                    r.Image = reader.GetString(2);
                    r.CurrentJobStart = reader.GetDateTime(3);
                    r.StartDate = reader.GetDateTime(4);

                    if (r is Student)
                    {
                        var s = r as Student;
                        s.Degree = reader.GetString(5);
                        string supervisorId = reader.GetString(6);

                        reader.Close();
                        MySqlCommand command2 = new MySqlCommand("select title, given_name, family_name from researcher where id = '" + supervisorId + "'", connection);
                        reader = command2.ExecuteReader();

                        if (reader.Read())
                        {
                            s.Supervisor = string.Format("{0} {1} {2}", reader.GetString(0), reader.GetString(1), reader.GetString(2));
                        }
                    }

                    else if (r is Staff)
                    {
                        var s = r as Staff;
                        List<string> supervisees = new List<string>();
                        List<Position> positions = new List<Position>();

                        reader.Close();
                        MySqlCommand command2 = new MySqlCommand("select title, given_name, family_name from researcher where supervisor_id = '" + s.Id + "'", connection);
                        reader = command2.ExecuteReader();

                        // Fetch selected title, given_name, family_name
                        while (reader.Read())
                        {
                            supervisees.Add(string.Format("{0} {1} {2}", reader.GetString(0), reader.GetString(1), reader.GetString(2)));
                        }

                        supervisees.Sort();
                        s.Supervisees = supervisees;


                        reader.Close();
                        MySqlCommand command3 = new MySqlCommand("select * from position where id = '" + r.Id + "'", connection);
                        reader = command3.ExecuteReader();

                        // Omitting current position by checking end date
                        while (reader.Read())
                        {
                            if (!reader.IsDBNull(3))

                                positions.Add(new Position
                                {
                                    Level = reader.GetString(1).ToEnum<EmploymentLevel>(),
                                    Start = reader.GetDateTime(2),
                                    End = reader.GetDateTime(3)
                                });
                        }
                        positions.Sort((position1, position2) => position2.Start.CompareTo(position1.Start));
                        s.Positions = positions;
                    }

                    reader.Close();
                    MySqlCommand command4 = new MySqlCommand("select doi, title, year from publication where doi in (select doi from researcher_publication where researcher_id = '" + r.Id + "')", connection);
                    reader = command4.ExecuteReader();

                    // Fetch selected doi, title, publication_year
                    while (reader.Read())
                    {
                        publications.Add(new Publication
                        {
                            Doi = reader.GetString(0),
                            Title = reader.GetString(1),
                            PublicationYear = reader.GetInt32(2)
                        });
                    }
                    r.Publications = publications;
                }
            }

            // Catch fetching errors
            catch (MySqlException error)
            {
                Console.WriteLine("Error connecting to Database: " + error);
            }
            // Close any remaining connections
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }

        // Fetch details of an entry in publication table
        public static void FetchPublicationFull(Publication p)
        {
            MySqlConnection connection = GetConnection();
            MySqlDataReader reader = null;

            try
            {
                connection.Open();

                MySqlCommand command = new MySqlCommand("select authors, type, cite_as, available from publication where doi = '" + p.Doi + "'", connection);
                reader = command.ExecuteReader();

                if (reader.Read())
                {
                    p.Authors = reader.GetString(0);
                    p.Type = reader.GetString(1).ToEnum<OutputType>();
                    p.CiteAs = reader.GetString(2);
                    p.Available = reader.GetDateTime(3);
                }
            }

            // Catch fetching errors
            catch (MySqlException error)
            {
                Console.WriteLine("Error connecting to Database: " + error);
            }

            // Close any remaining open connections
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }
    }
}