﻿/* Research Assessment Program (RAP)
 * 
 * ReportController.cs
 * Fetching and filtering for Performance Report
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System.Linq;
using System.Windows;
using System.ComponentModel;
using System.Windows.Controls;
using System.Collections.Generic;
using RAP.Database;
using RAP.Research;

namespace RAP.Control
{
    public enum PerformanceTier
    {
        [Description("Star Performers")] StarPerformers,
        [Description("Meeting Minimum")] MeetingMinimum,
        [Description("Below Expectations")] BelowExpectations,
        [Description("Poor Performers")] PoorPerformers
    }

    public static class ReportsControl
    {

        private static List<Staff> researchers;
        private static double[] valueTier = { 1000.0, 2.0, 1.1, 0.7, 0.0 };


        // Gets performance metric differently for reports, to avoid enormous database queries
        public static void LoadPerformanceDetails()
        {
            List<int> publicationAuthorIDs = RAPDatabase.FetchPublicationsBasic();
            Dictionary<int, int> publicationCounts;
            List<Staff> authors;

            var filterStaffQuery =
                from researcher in ResearcherControl.Researchers
                where researcher is Staff
                select researcher as Staff;

            // A list of only Staff entries in Researchers
            authors = filterStaffQuery.ToList();

            var filterPublicationsQuery =
                from entry in publicationAuthorIDs
                group entry by entry into uniqueEntry
                select new { Key = uniqueEntry.Key, Count = uniqueEntry.Count() };

            publicationCounts = filterPublicationsQuery.ToDictionary(x => x.Key, x => x.Count);

            foreach (Staff author in authors)
            {
                author.RecentPublicationCount = publicationCounts.ContainsKey(author.Id) ? publicationCounts[author.Id] : 0;
            }
            researchers = authors;
        }


        // Translates from selected tier name to the literal bounds
        public static List<Staff> GenerateReport(object tier)
        {
            PerformanceTier reportTier = tier.ToString().ToEnum<PerformanceTier>();

            switch (reportTier)
            {
                case PerformanceTier.StarPerformers:
                    return Sort(FilterBy(valueTier[0], valueTier[1]), true);
                case PerformanceTier.MeetingMinimum:
                    return Sort(FilterBy(valueTier[1], valueTier[2]), true);
                case PerformanceTier.BelowExpectations:
                    return Sort(FilterBy(valueTier[2], valueTier[3]), false);
                case PerformanceTier.PoorPerformers:
                    return Sort(FilterBy(valueTier[3], valueTier[4]), false);
                default: return null;
            }
        }


        // Return only staff in required tier
        private static List<Staff> FilterBy(double max, double min)
        {
            var filterQuery =
                from entry in researchers
                where entry.PerformanceMetric >= min &&
                entry.PerformanceMetric < max
                select entry;

            return filterQuery.ToList();
        }


        // Sort different reports in different ways
        private static List<Staff> Sort(List<Staff> researchers, bool ascending)
        {
            if (ascending)
            {
                researchers.Sort((researcher1, researcher2) => researcher2.PerformanceMetric.CompareTo(researcher1.PerformanceMetric));
            }
            else
            {
                researchers.Sort((researcher1, researcher2) => researcher1.PerformanceMetric.CompareTo(researcher2.PerformanceMetric));
            }
            return researchers;
        }


        // Put a string on the clipboard
        public static void LoadEmails(ItemCollection researchers)
        {
            List<Staff> researcherList = researchers.OfType<Staff>().ToList();
            string researcherEmails = "";

            foreach (Staff researcher in researcherList)
            {
                researcherEmails += (researcher.Email + ", ");
            }
            Clipboard.SetText(researcherEmails);
        }
    }
}