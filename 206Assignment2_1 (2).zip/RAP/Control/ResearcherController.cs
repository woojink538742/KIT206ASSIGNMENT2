﻿/* Research Assessment Program (RAP)
 * 
 * ResearcherControl.cs
 * Fetching and filtering of Researchers
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System.Linq;
using System.Collections.Generic;
using RAP.Database;
using RAP.Research;

namespace RAP.Control
{
    public static class ResearcherControl
    {

        public static List<Researcher> Researchers { get; private set; }
        public static Researcher CurrentResearcher { get; private set; }

        // Get basic details of researchers
        public static List<Researcher> LoadResearchers()
        {
            Researchers = RAPDatabase.FetchResearcherDetails();
            return Researchers;
        }


        // Return researchers within given parameters only
        public static List<Researcher> FilterBy(string query, object type)
        {
            List<Researcher> researchers = Researchers;
            EmploymentLevel level = type.ToString().ToEnum<EmploymentLevel>();
            string name = query.ToUpper(); // For case insensitive search

            // if they have specified a level => filter by it
            if (level != EmploymentLevel.Unspecified)
            {
                var filterQuery1 =
                    from entry in researchers
                    where entry.CurrentJob == level
                    select entry;

                researchers = filterQuery1.ToList();
            }

            // filter by its condition
            if (query != "")
            {
                var filterQuery2 =
                    from entry in researchers
                    where (entry.GivenName.ToUpper().Contains(name)
                        || entry.FamilyName.ToUpper().Contains(name))
                    select entry;
                researchers = filterQuery2.ToList();
            }
            return researchers.OrderBy(x => x.FamilyName).ToList();
        }

        // Get details of researcher upon selection
        public static void LoadResearcherDetails(object selected)
        {
            if (selected != null)
            {
                RAPDatabase.FetchResearcherFull((Researcher)selected);
            }
            CurrentResearcher = (Researcher)selected;
        }
    }
}