﻿/* Research Assessment Program (RAP)
 * 
 * PublicationsControl.cs
 * Fetching and filtering of Publications
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.Linq;
using System.Windows.Controls;
using System.Collections.Generic;
using RAP.Database;
using RAP.Research;

namespace RAP.Control
{
    public static class PublicationsControl
    {
        public static List<string> PublicationYears { get; private set; }
        public static Publication CurrentPublication { get; private set; }
        public static bool SortDescending { get; private set; }

        // Get general publication details for selected researcher
        public static List<Publication> LoadPublications()
        {
            Researcher researcher = ResearcherControl.CurrentResearcher;
            SortDescending = true;

            if (researcher != null)
            {
                // Used to populate refinement combobox with only the years from commencement to now
                PublicationYears = Enumerable.Range(researcher.StartDate.Year, DateTime.Today.Year - (researcher.StartDate.Year - 1))
                    .Select(n => n.ToString()).ToList();

                // Plus a default/open-ended option
                PublicationYears.Insert(0, "");

                return researcher.Publications.Sorted();
            }
            return null;
        }


        // Returns only publications published in between the years given
        public static List<Publication> FilterBy(int year1, int year2)
        {
            // in case the user is strange and enters backwards values
            int earliestYear = Math.Min(year1, year2);
            int latestYear = Math.Max(year1, year2);

            var filterQuery =
                from entry in ResearcherControl.CurrentResearcher.Publications
                where entry.PublicationYear >= earliestYear &&
                    entry.PublicationYear <= latestYear
                select entry;

            return filterQuery.ToList().Sorted();
        }


        // Returns a list of <year, number of publications that year> pairs
        public static List<Tuple<int, int>> CumulativeCount()
        {
            List<Tuple<int, int>> results = new List<Tuple<int, int>>();
            Researcher researcher = ResearcherControl.CurrentResearcher;

            if (researcher != null)
            {
                int start = researcher.StartDate.Year;
                int current = DateTime.Today.Year;

                for (int year = start; year <= current; year++)
                {
                    var filterQuery =
                        from entry in ResearcherControl.CurrentResearcher.Publications
                        where entry.PublicationYear == year
                        select entry;
                    results.Add(new Tuple<int, int>(year, filterQuery.Count()));
                }
                return results;
            }
            return null;
        }

        // Queries database for full publication details upon selection
        public static void LoadPublicationDetails(object selected)
        {
            if (selected != null)
            {
                RAPDatabase.FetchPublicationFull((Publication)selected);
            }
            CurrentPublication = (Publication)selected;
        }

        // Sorts given list by current sort order (to maintain it even after new refinements)
        public static List<Publication> InvertSortOrder(ItemCollection publications)
        {
            SortDescending = !SortDescending;
            return publications.OfType<Publication>().ToList().Sorted();
        }

        // Used by the above because if I put all these calls on one line we'd both get a headache
        private static List<Publication> Sorted(this List<Publication> publications)
        {
            if (SortDescending)
            {
                return publications.OrderByDescending(x => x.PublicationYear).ThenBy(x => x.Title).ToList();
            }
            else
            {
                return publications.OrderBy(x => x.PublicationYear).ThenBy(x => x.Title).ToList();
            }
        }
    }
}