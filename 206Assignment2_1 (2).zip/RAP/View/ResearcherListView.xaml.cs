﻿/* Research Assessment Program (RAP)
 * 
 * ResearcherListView.cs
 * Manages the data about list of researchers
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Controls;
using RAP.Control;

namespace RAP.View
{
    public partial class ResearcherListView : UserControl 
    {

        public ResearcherListView()
        {
            ResearcherControl.LoadResearchers();
            InitializeComponent();

            // it takes displayed ResearcherList in order
            ResearcherCategories.SelectedIndex = 0;
        }

        // makes filter which applied when takes the new input from selection box
        private void ResearcherCategories_SelectionChanged(object sender, EventArgs e)
        {
            ResearcherList.ItemsSource = ResearcherControl.FilterBy(SearchBox.Text, ResearcherCategories.SelectedValue);
        }

        // makes filter which applied when press button from searchbox
        private void SearchBox_QueryEntered(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                ResearcherList.ItemsSource = ResearcherControl.FilterBy(SearchBox.Text, ResearcherCategories.SelectedValue);
            }
        }

        // for updating the data of ResearcherDetailsView when the data of list is selected
        private void ResearcherList_SelectionChanged(object sender, EventArgs e)
        {
            ResearcherControl.LoadResearcherDetails(ResearcherList.SelectedItem);
            ((MainWindow)Application.Current.MainWindow).UpdateResearcherDetailsView();
        }

        // for opening a display which is showing the report in ReportsView
        private void GenerateReportsButton_Clicked(object sender, EventArgs e)
        {
            if (ReportsView.CurrentReportsView == null)
            {
                ReportsView popover = new ReportsView();
                popover.Show();
            }
            else
            {
                ReportsView.CurrentReportsView.Activate();
            }
        }
    }
}
