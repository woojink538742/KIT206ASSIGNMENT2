/* Research Assessment Program (RAP)
 * 
 * App.xaml.cs
 * class files for Application
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System.Windows;
   
namespace RAP.View {
    public partial class App : Application {}
}