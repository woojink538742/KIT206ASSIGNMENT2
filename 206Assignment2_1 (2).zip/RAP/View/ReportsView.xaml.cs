﻿/* Research Assessment Program (RAP)
 * 
 * ReportsView.xaml.cs
 * Manage Report View
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.Windows;
using RAP.Control;

namespace RAP.View
{
    public partial class ReportsView : Window
    {
        public static ReportsView CurrentReportsView { get; private set; }

        public ReportsView()
        {
            CurrentReportsView = this;
            ReportsControl.LoadPerformanceDetails();
            InitializeComponent();

            // set the default value of data of Performance Tier
            PerformanceTiersCombobox.SelectedIndex = 0;
        }

        // it makes the report list as a default status
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            CurrentReportsView = null;
        }

        // take the data which is relevant with selected tier
        private void PerformanceTiersCombobox_SelectionChanged(object sender, EventArgs e)
        {
            PerformerList.ItemsSource = ReportsControl.GenerateReport(PerformanceTiersCombobox.SelectedValue);
        }

        // it copies selected researcher's email to clipboard
        private void CopyEmailsButton_Click(object sender, RoutedEventArgs e)
        {
            ReportsControl.LoadEmails(PerformerList.Items);
        }
    }
}
