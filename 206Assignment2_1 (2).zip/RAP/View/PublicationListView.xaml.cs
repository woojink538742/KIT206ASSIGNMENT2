﻿/* Research Assessment Program (RAP)
 * 
 * PublicationListView.xaml.cs
 * Display the list of publication 
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.Windows;
using System.Windows.Controls;
using RAP.Control;

namespace RAP.View
{
    public partial class PublicationListView : UserControl
    {
       
        public PublicationListView()
        {
            InitializeComponent();
        }

        // it takes displayed publication year in order 
        private void PublicationsList_YearHeaderClicked(object sender, EventArgs e)
        {
            PublicationsList.ItemsSource = PublicationsControl.InvertSortOrder(PublicationsList.Items);
        }

        // it takes the user input year and returns ordered the list
        private void RefinePublicationsButton_Clicked(object sender, EventArgs e)
        {
            int selected1;
            int selected2;

            if (ResearcherControl.CurrentResearcher != null)
            {
                // when user does not enter anything in the first blank, the lowest will come to the first blank
                if (!int.TryParse(PublicationsYearBox1.Text, out selected1))
                {
                    selected1 = DateTime.MinValue.Year;
                }

                // when user does not enter anything in the second blank, the latest will come to the second blank
                if (!int.TryParse(PublicationsYearBox2.Text, out selected2))
                {
                    selected2 = DateTime.Today.Year;
                }

                PublicationsList.ItemsSource = PublicationsControl.FilterBy(selected1, selected2);
            }
        }

        // it requests publication data from database package and makes other views displayed
        private void PublicationsList_SelectionChanged(object sender, EventArgs e)
        {
            PublicationsControl.LoadPublicationDetails(PublicationsList.SelectedItem);
            ((MainWindow)Application.Current.MainWindow).UpdateOtherDetailsView(DetailsView.Publication);
        }
    }
}
