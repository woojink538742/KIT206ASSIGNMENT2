﻿/* Research Assessment Program (RAP)
 * 
 * PublicationDetailsView.xaml.cs
 * Make control of PublicationDetail and display the details of it
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System.Windows.Controls;
using RAP.Control;

namespace RAP.View
{
    public partial class PublicationDetailsView : UserControl
    {
        public PublicationDetailsView()
        {
            InitializeComponent();
            DataContext = PublicationsControl.CurrentPublication;
        }
    }
}
