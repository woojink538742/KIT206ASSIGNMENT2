﻿/* Research Assessment Program (RAP)
 * 
 * ResearcherDetailsView.cs
 * Manages the data about Researcher's details
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.Windows;
using System.Windows.Controls;

namespace RAP.View
{
    public partial class ResearcherDetailsView : UserControl
    {
        public ResearcherDetailsView()
        {
            InitializeComponent();
        }

        // calls a SupervisesView as content for OtherDetailsView
        private void ShowNamesButton_Clicked(object sender, EventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).UpdateOtherDetailsView(DetailsView.Supervisees);
        }

        // calls a CumulativeCountView as content for OtherDetailsView
        private void CumulativeCountButton_Clicked(object sender, EventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).UpdateOtherDetailsView(DetailsView.CumulativeCount);
        }
    }
}
