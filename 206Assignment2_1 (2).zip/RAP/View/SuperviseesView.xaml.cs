﻿/* Research Assessment Program (RAP)
 * 
 * SupervisesView.xaml.cs
 * manage the data of SupervisesView
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System.Windows.Controls;
using RAP.Control;

namespace RAP.View
{
    public partial class SuperviseesView : UserControl
    {
        public SuperviseesView()
        {
            InitializeComponent();
            DataContext = ResearcherControl.CurrentResearcher;
        }
    }
}
