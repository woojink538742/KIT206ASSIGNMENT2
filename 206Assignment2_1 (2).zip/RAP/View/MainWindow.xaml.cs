﻿/* Research Assessment Program (RAP)
 * 
 * MainWindow.cs
 * Display ResearcherListView, ResearcherDetailView, and OtherDetailView
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System;
using System.Windows;
using RAP.Control;

namespace RAP.View
{
    internal enum DetailsView { Publication, Supervisees, CumulativeCount };

    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
            RDV.IsEnabled = false;
        }

        // close the window event running on background
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            Application.Current.Shutdown();
        }


        // Update details of data of researcher when it meets the appropriate circumstance
        internal void UpdateResearcherDetailsView()
        {
            if (ResearcherControl.CurrentResearcher != null)
            {
                // make the researcher got details data
                RDV.DataContext = ResearcherControl.CurrentResearcher;
                RDV.IsEnabled = true;

                // set the PublicationListView of specific researcher
                RDV.PLV.PublicationsList.ItemsSource = PublicationsControl.LoadPublications();
                RDV.PLV.PublicationsYearBox1.ItemsSource = PublicationsControl.PublicationYears;
                RDV.PLV.PublicationsYearBox2.ItemsSource = PublicationsControl.PublicationYears;

                // Set Publication Year as default value 0
                RDV.PLV.PublicationsYearBox1.SelectedIndex = 0;
                RDV.PLV.PublicationsYearBox2.SelectedIndex = 0;

                // hide OtherDetailView for a while
                ODV.Content = null;
            }
        }


        // Update details of data of other thing except ResearcherDetail when it meets the appropriate circumstance
        internal void UpdateOtherDetailsView(DetailsView view)
        {
            // Use switch to move to the different views with control 
            switch (view)
            {
                
                case DetailsView.Publication:

                    if (!(ODV is PublicationDetailsView))
                    {
                        // make the new PublicationDetailView
                        ODV.Content = new PublicationDetailsView();
                    }

                    // move to PublicationController and viewing CurrentPublication
                    ODV.DataContext = PublicationsControl.CurrentPublication;
                    break;

                
                case DetailsView.Supervisees:
                    // make the new SuperviseView
                    ODV.Content = new SuperviseesView();
                    break;

                
                case DetailsView.CumulativeCount:
                    // make the new CumulativeCountView
                    ODV.Content = new CumulativeCountView();
                    break;
            }
            
        }
    }
}
