﻿/* Research Assessment Program (RAP)
 * 
 * CumulativeCountView.cs
 * Manages Cumulative Count of Publication
 * Authors: Woojin Kim, Wonpyo Hong, Rashmi Sharma
 * Last edited date : 26.05.2021
 */

using System.Windows.Controls;
using RAP.Control;

namespace RAP.View
{
    public partial class CumulativeCountView : UserControl
    {
        public CumulativeCountView()
        {
            InitializeComponent();
            CumulativeCountList.ItemsSource = PublicationsControl.CumulativeCount();
        }
    }
}
